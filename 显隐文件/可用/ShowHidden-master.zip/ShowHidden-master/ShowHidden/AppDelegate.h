//
//  AppDelegate.h
//  ShowHidden
//
//  Created by Vincenzo Pimpinella on 15/12/13.
//  Copyright (c) 2013 Vincenzo Pimpinella. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
