//
//  main.m
//  ShowHidden
//
//  Created by Vincenzo Pimpinella on 15/12/13.
//  Copyright (c) 2013 Vincenzo Pimpinella. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
