# ShowHidden
A simple gui to show ad hide, the hidden files on OS X
