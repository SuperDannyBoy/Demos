//
//  AppDelegate.h
//  NSStatusItemExample
//
//  Created by Tim Jarratt on 3/31/13.
//  Copyright (c) 2013 Tim Jarratt. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {
    NSStatusItem *statusItem;
    bool eyeIsClosed;
}

@end
