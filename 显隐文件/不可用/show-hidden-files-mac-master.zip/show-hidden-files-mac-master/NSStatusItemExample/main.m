//
//  main.m
//  NSStatusItemExample
//
//  Created by Tim Jarratt on 3/31/13.
//  Copyright (c) 2013 Tim Jarratt. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
